from ui import main_view

main_view.show()
